"""Structural checks only; this cannot validate the truth of a scientific claim."""
import json, sys
from datetime import date
from urllib.parse import urlparse

SUPPORTED={'toggle','water','calibrate','send','recharge','move','wake'}

def validate(card):
    errors=[]
    def required(obj,field,prefix):
        value=obj.get(field) if isinstance(obj,dict) else None
        if not isinstance(value,str) or not value.strip(): errors.append(prefix+field+' is required')
    for field in ['id','axis']: required(card,field,'')
    for section,fields in {
        'source':['title','url','organization','locator','accessed_on','dataset_or_mission'],
        'fact':['statement','environment','conditions','limitations'],
        'educational_model':['child_explanation_en','simplification','limits'],
        'game_balance':['rationale'],
        'mission':['observation','decision','immediate_effect','later_effect','neilo_response_en','recovery','transfer_question_en'],
    }.items():
        obj=card.get(section,{})
        if not isinstance(obj,dict): errors.append(section+' must be an object'); continue
        for field in fields: required(obj,field,section+'.')
    source=card.get('source',{})
    if isinstance(source,dict):
        parsed=urlparse(str(source.get('url','')))
        if parsed.scheme not in ['http','https'] or not parsed.netloc: errors.append('source.url must be an HTTP(S) URL')
        try: date.fromisoformat(source.get('accessed_on',''))
        except (ValueError,TypeError): errors.append('source.accessed_on must be YYYY-MM-DD')
    fact=card.get('fact',{})
    if isinstance(fact,dict) and fact.get('quantitative'):
        if fact.get('value') is None: errors.append('quantitative fact needs a value')
        required(fact,'units','fact.')
    balance=card.get('game_balance',{})
    if not isinstance(balance,dict) or balance.get('fictional') is not True: errors.append('game_balance.fictional must explicitly be true')
    mission=card.get('mission',{})
    if not isinstance(mission,dict) or not isinstance(mission.get('choices'),list) or len(mission['choices'])<2: errors.append('mission needs at least two choices')
    impl=card.get('implementation',{})
    if not isinstance(impl,dict): errors.append('implementation must be an object')
    else:
        status=impl.get('status')
        if status not in ['unmapped','supported','new-mechanic-required']: errors.append('invalid implementation.status')
        actions=impl.get('engine_actions',[])
        if not isinstance(actions,list): errors.append('engine_actions must be an array')
        elif status=='supported' and (not actions or any(not isinstance(a,str) or a not in SUPPORTED for a in actions)): errors.append('supported card must map to known engine actions')
        if status=='new-mechanic-required': required(impl,'work_needed','implementation.')
    review=card.get('review',{})
    if not isinstance(review,dict): errors.append('review must be an object')
    else:
        status=review.get('status')
        if status not in ['needs-review','approved','rejected']: errors.append('invalid review.status')
        if status=='approved':
            required(review,'reviewer','review.')
            try: date.fromisoformat(review.get('reviewed_on',''))
            except (ValueError,TypeError): errors.append('approved card needs reviewed_on date')
        if status=='rejected': required(review,'reason','review.')
    return errors

def main():
    try:
        data=json.load(open(sys.argv[1],encoding='utf-8-sig'))
        cards=data if isinstance(data,list) else [data]
        if not cards: raise ValueError('No cards supplied')
        rows=[]; ids=set()
        for i,card in enumerate(cards):
            errors=validate(card) if isinstance(card,dict) else ['card must be an object']
            card_id=card.get('id') if isinstance(card,dict) else None
            if card_id in ids: errors.append('duplicate card id')
            if isinstance(card_id,str): ids.add(card_id)
            rows.append({'index':i,'id':card_id,'errors':errors})
        print(json.dumps({'scope':'STRUCTURE ONLY; not scientific approval or game integration','cards':rows},ensure_ascii=True,indent=2))
        return int(any(row['errors'] for row in rows))
    except (OSError,ValueError,IndexError,TypeError) as e:
        print('Invalid input: '+str(e),file=sys.stderr);return 2

if __name__=='__main__': sys.exit(main())
