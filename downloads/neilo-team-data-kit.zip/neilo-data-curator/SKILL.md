---
name: neilo-data-curator
description: Review NASA challenge resources and turn sourced scientific facts into reviewed NEILO mission cards for a children's Mars game. Use when collecting or checking scientific content for NEILO, not when generating arbitrary game missions or giving medical advice.
---

# NEILO scientific content workflow

NEILO is an English browser game for ages 7–12. A child and a friendly robot restore a fictional Mars base. The prototype supports shared electrical capacity, device switching, battery, water preparation, antenna calibration and sending a signal. Food cultivation, radiation protection and rescue travel are not implemented systems yet. Do not imply that writing a card implements a mechanic.

When challenge resources become available, read the actual challenge and its Resources first. Prefer the supplied NASA sources. For global eligibility, the GO Team answer of 5 November 2026 says to use at least one NASA data source included in the challenge Resources and cite all resources: https://github.com/nasa/spaceapps/discussions/1827 . A generic NASA homepage or decorative NASA reference does not demonstrate meaningful use of a dataset. The proposal template also requires at least one scientific paper; distinguish registration requirements from final submission fields.

## Work product

Use `data-card.template.json` for each claim. Return a short screening table (suitable / needs review / outside scope), then the cards and the exact missing evidence. Preserve links, page/table/section identifiers, units, environment and applicability limits. Access dates should reflect actual access. If a source is unavailable, mark it unverified; never invent its contents.

Separate these three layers:

- **Source fact:** what the source actually measured or states, with its conditions. Lunar, terrestrial, orbital and Mars evidence are not interchangeable.
- **Educational simplification:** the deliberately simplified explanation/model, plus its limitations.
- **Game balance:** fictional units, costs and timing chosen for play. Label these as design values, never NASA measurements.

One card should support one understandable player decision. Specify what the child observes, supported actions, immediate and later consequences, NEILO's short English response, a recoverable failure, and a transfer question with changed conditions. Allow multiple successful strategies where the science supports them. Do not reduce every task to a correct/incorrect quiz or invent unrelated mini-games.

For quantitative claims require units and conditions. A radiation measurement alone does not justify safe human exposure limits, a health diagnosis, or the effectiveness of an arbitrary shielding material. Plant growth requires elapsed story time consistent with the model; no instant harvest disguised as real data. Delay in communication must distinguish Earth–Mars links from a nearby orbiting crew.

Check whether the card uses an existing engine action. If it needs a new system, set `implementation.status` to `new-mechanic-required` and describe the engineering work. Do not promise that importing the card will run it.

Keep new cards `needs-review`. A named human reviewer verifies the scientific interpretation before `approved`. The structural validator cannot verify scientific truth. Keep rejected cards with reasons instead of silently treating them as accepted.

## Handoff

Run `python scripts/validate_cards.py path/to/cards.json` for structural checks. Files may contain a card or an array. This command does not integrate content into the game. Deliver reviewed cards to the developer; integration needs explicit action mapping, UI feedback and gameplay verification.

Do not send messages, submit competition forms, change the game's audience, or publish a build as part of this skill. Use the team's confirmed event schedule, not a date inferred from a global event listing.
